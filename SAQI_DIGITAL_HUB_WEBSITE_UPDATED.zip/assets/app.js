document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu-toggle'), panel=document.querySelector('.side-menu'), backdrop=document.querySelector('.menu-backdrop'), close=document.querySelector('.menu-close');
 const setMenu=(open)=>{if(!toggle||!panel||!backdrop)return;toggle.classList.toggle('is-open',open);toggle.setAttribute('aria-expanded',String(open));panel.classList.toggle('open',open);panel.setAttribute('aria-hidden',String(!open));backdrop.classList.toggle('show',open);document.body.classList.toggle('menu-lock',open)};
 if(toggle)toggle.addEventListener('click',()=>setMenu(!panel.classList.contains('open')));
 if(close)close.addEventListener('click',()=>setMenu(false));
 if(backdrop)backdrop.addEventListener('click',()=>setMenu(false));
 if(panel)panel.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setMenu(false)));
 document.addEventListener('keydown',e=>{if(e.key==='Escape')setMenu(false)});
 const year=document.getElementById('year');if(year)year.textContent=new Date().getFullYear();
 const input=document.getElementById('priceSearch');if(input)input.addEventListener('input',()=>{const q=input.value.toLowerCase().trim();document.querySelectorAll('.price-card').forEach(card=>card.classList.toggle('hidden',!card.innerText.toLowerCase().includes(q)))});
 // Load recognizable brand SVGs automatically from Simple Icons CDN when that brand has an available icon.
 // If a brand has no icon in the library, its readable name remains as a graceful fallback.
 const slugs={'NETFLIX':'netflix','PRIME VIDEO':'primevideo','HBO MAX':'hbo','DISNEY+':'disneyplus','HULU':'hulu','PARAMOUNT+':'paramountplus','PEACOCK':'peacock','BRITBOX':'britbox','ZEE5':'zee5','CRUNCHYROLL':'crunchyroll','NORDVPN':'nordvpn','SURFSHARK':'surfshark','EXPRESSVPN':'expressvpn','PROTON VPN':'protonvpn','IPVANISH':'ipvanish','CAPCUT PRO':'capcut','CANVA PRO':'canva','PICSART':'picsart','LEONARDO AI':'leonardo','CHATGPT':'openai','GEMINI':'googlegemini','GROK':'x','GRAMMARLY':'grammarly','QUILLBOT':'quillbot','ELEVENLABS':'elevenlabs','GOOGLE FLOW':'google'};
 document.querySelectorAll('.auto-logos .logo-track span').forEach(el=>{const label=el.textContent.trim().toUpperCase();const slug=slugs[label];if(!slug)return;const img=document.createElement('img');img.alt=label+' logo';img.loading='lazy';img.src='https://cdn.simpleicons.org/'+slug;img.onerror=()=>img.remove();el.prepend(img)});
});